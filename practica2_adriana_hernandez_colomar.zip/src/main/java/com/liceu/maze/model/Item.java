package com.liceu.maze.model;

public interface Item {
    String getItemString();

}
