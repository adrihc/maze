package com.liceu.maze.model;
public class Coin implements Item{
    String itemString = "coin";


    public String getItemString(){
        return itemString;
    }
}
