package com.liceu.maze.model;
public class Wall implements Direction{
    String direction = "wall";

    public String getDirection() {
        return direction;
    }
}
