package com.liceu.maze.model;

public interface Direction {
    String getDirection();
}
